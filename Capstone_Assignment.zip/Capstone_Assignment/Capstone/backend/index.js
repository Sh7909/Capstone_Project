const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const mongoose = require("mongoose");
const { booksarray } = require("./booksdata");
const PORT = 3000;
const app = express();
app.use(cors());
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));

mongoose
  .connect("mongodb://localhost:27017/reactdatabase")
  .then(() => console.log("Database Connected"));
const schema = new mongoose.Schema({
  Formdata: {
    firstname: String,
    lastname: String,
    email: String,
    password1: String,
    password2: String,
  },
});
const BooksSchema = new mongoose.Schema({
  id: String,
  category: String,
  title: String,
  img: String,
  Price: String,
  Description:String,
});
const myModel = new mongoose.model("MyModel", schema);
const BooksModel = new mongoose.model("BooksModel", BooksSchema);
BooksModel.find().then((books) => {
  if (books.length === 0) {
    BooksModel.insertMany(booksarray)
      .then(() => console.log("Books inserted"))
      .catch((err) => console.error("Insert error", err));
  } else {
    console.log("Books already exist");
  }
});

app.post("/sendlogindata", (req, res) => {
  const { Formdata } = req.body;
  myModel.create({ Formdata });
  res.json({ message: "Data Received" });
});
app.post("/checkvalidation", async (req, res) => {
  try {
    const { loginemailinput, loginpassinput } = req.body;

    const user = await myModel.findOne({
      "Formdata.email": loginemailinput,
      "Formdata.password1": loginpassinput,
    });

    if (user) {
      res.json({
        found: true,
        email: user.Formdata.email,
        message: "Login Successful",
      });
    } else {
      res.json({
        found: false,
        message: "Please enter valid credentials!",
      });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Server error" });
  }
});

app.get("/getbooksdata", async (req, res) => {
  try {
    const booksdata = await BooksModel.find({ category: "Mystery Book" });
    return res.json(booksdata);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to fetch books data" });
  }
});
app.get("/gethistorybookdata", async (req, res) => {
  try {
    const booksdata2 = await BooksModel.find({ category: "History Book" });
    return res.json(booksdata2);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to fetch books data" });
  }
});
app.get("/getsciencebookdata", async (req, res) => {
  try {
    const booksdata3 = await BooksModel.find({ category: "Science Fiction" });
    return res.json(booksdata3);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to fetch books data" });
  }
});

app.get("/getadventurebookdata", async (req, res) => {
  try {
    const booksdata4 = await BooksModel.find({ category: "Adventure Fiction" });
    return res.json(booksdata4);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to fetch books data" });
  }
});

app.get("/gethorrorbookdata", async (req, res) => {
  try {
    const booksdata5 = await BooksModel.find({ category: "Horror" });
    return res.json(booksdata5);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to fetch books data" });
  }
});
app.get("/getfantasybookdata", async (req, res) => {
  try {
    const booksdata6 = await BooksModel.find({ category: "Fantasy" });
    return res.json(booksdata6);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to fetch books data" });
  }
});
app.listen(PORT, () => {
  console.log(`Server Started Now ${PORT}`);
});
