const booksarray = [
  {
    id: "1",
    category: "Mystery Book",
    title: "The Mystery of the Hidden Lab",
    img: "../images/mysterybook1.png",
    Price: "295",
    Description:
      "Rachel Clarke, an eminent YouTuber, jolts upright as she sees theheadlines on TV. “A hundred thousand people want to storm into Area 51.” She is stunned. Four years ago, she made videos suggesting that the government of the USA is hiding extraterrestrial beings within the surreptitious borders of United States Air Force Facility, aka Area51. She is sure that nobody believed her story at that time.But presently, it seems that the public in America is determined to know what secrets the government is hiding there. Is it because of my videos? The thought troubles her, as she contemplates the sudden upheaval of events. And then, she receives a call. A call, that is not only going to land her into the most secret, the most bizarre science facility located near the mystified borders of Area 51, but also going to turn her world up side down. Her life is going to change forever. Thrilling adventures, unsolved mysteries, sinister plots.... ....an introductory installment to the Rachel Clarke series that leaves you spellbound, keeping you on the edge of your seat till the very end.",
  },
  {
    id: "2",
    category: "Mystery Book",
    title: "Secret of the Staircase: 4",
    img: "../images/mysterybook2.png",
    Price: "400",
    Description: `Magic Tree House meets Hardy Boys. The perfect blend of history and mystery for kids - read it as a standalone or with the full series!
Something's lurking beneath the famous staircase at The Jefferson, Richmond's historic downtown hotel. Back in 1895, when the hotel opened, real alligators roamed free in the courtyard fountains. That was ages ago ... or was it? When young brothers Sam and Derek arrive at The Jefferson for an elegant wedding weekend with their parents, they love exploring the old hotel. But when the wedding rings go missing and Sam is blamed, the boys and their friends must hunt down the truth no matter where it leads. If they're not careful, they might become dinner for the hotel's most unusual guests.`,
  },
  {
    id: "3",
    category: "Mystery Book",
    title: "THE SILENT PATIENT",
    img: "../images/mysterybook3.png",
    Price: "200",
    Description: `WITH OVER THREE MILLION COPIES SOLD, read the Sunday Times and No.1 New York Times bestselling, record-breaking thriller that everyone is talking about - soon to be a major film.
'The perfect thriller' AJ FINN
'Terrific' - THE TIMES Crime Book of the Month
'Smart, sophisticated suspense' - LEE CHILD
'Compelling' - OBSERVER
'Absolutely brilliant' - STEPHEN FRY
'A totally original psychological mystery' - DAVID BALDACCI
'One of the best thrillers I've read this year' - CARA HUNTER
'The pace and finesse of a master' - BBC CULTURE
Alicia Berenson lived a seemingly perfect life until one day six years ago.When she shot her husband in the head five times.
Since then she hasn't spoken a single word.It's time to find out why.
THE SILENT PATIENT is the gripping must-read thriller of the year - perfect for fans of THE FAMILY UPSTAIRS by Lisa Jewell, BLOOD ORANGE by Harriet Tyce and PLAYING NICE by JP Delaney.`,
  },
  {
    id: "4",
    category: "Mystery Book",
    title:
      "365 Unsolved Mysteries: Tales of Ancient Puzzles, Ghost Stories, Cryptids & Enigmatic Events",
    img: "../images/mysterybook4.png",
    Price: "300",
    Description:
      "We live in a mystifying world. No wonder, many archaeological or scientific mysteries still remain unanswered. Some bizarre, notorious, and unsolved crimes of all time have puzzled detectives for decades. Lives of some famous personalities stay enveloped in ambiguity. Many startling aspects about the human body remain unknown. Mother Earth with her splendour leaves us awestruck as some natural phenomenon can't be explained. There is no dearth of accounts of all kinds that will surprise and shock you. Read 365 unsolved mysteries to know more.",
  },
  {
    id: "5",
    category: "Mystery Book",
    title: "Mystery Of The Missing Cat (Sms Detective Agency Book 2)",
    img: "../images/mysterybook5.png",
    Price: "500",
    Description: `The charming hill town of Solan is playing host to the cricketing match of the year - a match between India and Australia. Naturally, its close-knit community is all abuzz! Not only are the top cricketing stars going to descend upon them, but also the glamorous film star married to the dashing cricket captain. Will India manage to snatch a much-needed victory from the Aussies, is the big question. However, even before the match begins, it seems this victory might be slipping away. All because of a missing feline.
Enter the Super Mystery Solvers or the SMS gang of Aditya and Akriti, the nine-year-old twins, and their close friend Kabir. Can they find the missing cat and help India win the match? Together, they must solve this mystery that has even the police completely baffled.`,
  },
  {
    id: "6",
    category: "Mystery Book",
    title: "The Locked Door",
    img: "../images/mysterybook6.png",
    Price: "400",
    Description: `Some doors are locked for a reason...
While eleven-year-old Nora Davis was up in her bedroom doing homework, she had no idea her father was killing women in the basement.
Until the day the police arrived at their front door.
Decades later, Nora's father is spending his life behind bars, and Nora is a successful surgeon with a quiet, solitary existence. Nobody knows her father was a notorious serial killer. And she intends to keep it that way.
Then Nora discovers one of her young female patients has been murdered. In the same unique and horrific manner that her father used to kill his victims.
Somebody knows who Nora is. Somebody wants her to take the fall for this unthinkable crime. But she's not a killer like her father. The police can't pin anything on her.
As long as they don't look in her basement.
Get ready to experience an exhilarating ride of maddening twists and turns with this intense psychological thriller. Packed with adrenaline-pumping action and gripping suspense, this novel is perfect for readers who love fast-paced and enthralling mysteries.`,
  },
  {
    id: "7",
    category: "Mystery Book",
    title:
      "Living While Dead | The story of a man's search for meaning in life",
    img: "../images/mysterybook7.png",
    Price: "600",
    Description:
      "Nathan's journey has been one of unparalleled determination leading to remarkable success. Yet, as he stands at his father's funeral, the sight of the flames consuming his father's remains awakens deep emotions within him. As he scatters the ashes in the sacred waters of the Ganges, he experiences a moment of divine communion. The Ganga, moved by his sincerity, offers him a choice of unimaginable gifts: immortality, infinite wealth, eternal youth, or the supreme power to influence others. But Nathan seeks something more profound. What will Nathan ask of the Goddess Ganges? What is the one thing that could bring him peace? Will his choice transform not only his life but also the lives of others? In a world often driven by power and greed, can Nathan’s pursuit of a deeper meaning redefine what it means to truly live, even beyond death? Discover Nathan’s choice and its impact in this stirring tale of inner quest and transformation. Will kindness prevail over might, and empathy over desire? Join Nathan on his profound journey to realize his dream of 'living while dead.' Let's unravel his story together...",
  },
  {
    id: "8",
    category: "History Book",
    title: "Dadi: The Relentless Warrior",
    img: "../images/historybook1.png",
    Price: "100",
    Description: `DADI
(The Relentless Warrior)

Embark on a journey where old meets new, and ancient wisdom harmonizes with scientific development. The key to a balanced life lies in embracing both.

"Dadi" is a fictional story that discovers a way of life inspired by the profound knowledge of past civilizations. This book illuminates how their timeless insights can be integrated into our modern world, leading us to live in harmony with our environment.

"Dadi" is more than a narrative; it’s a call to action, urging each one of us to contribute to the story of sustainable development. By melding the lessons of our ancestors with the advancements of today. “Are We Humanity 2.O?”`,
  },
  {
    id: "9",
    category: "History Book",
    title: "Knowledge Encyclopedia - World History",
    img: "../images/historybook2.png",
    Price: "170",
    Description: `When and where did the first civilisations emerge? How did Britain lead the Industrial Revolution? What was the Suffrage Movement? This encyclopedia will answer these and more hows and whats for you. Learning is made simpler with well-labelled diagrams and an extensive glossary of difficult words. Bonus: the engrossing book comes loaded with Isn’t It Amazing—a section of fun facts to keep you glued for more. This encyclopedia is a must-read for all children!
It is well-researched and has child-friendly content
The various topics improve knowledge about the world around us and beyond
The content will cater to curious minds and expand their horizon
The book comprises a glossary of new and difficult terms
It is an excellent selection for gifting and school libraries`,
  },
  {
    id: "10",
    category: "History Book",
    title:
      "The Originals: A Short History of the World by H.G. Wells | Unabridged Classic | World History Book | Timeless History Book | Classic History Book",
    img: "../images/historybook3.png",
    Price: "300",
    Description: `H.G. Wells: Bridging Science Fiction and World History

One of the Founders of Innovative Science Fiction Novels, H.G Wells was as Taken up with the Real World as His Imaginary Realm. Dissatisfied with the Quality of History Books at the End of World War I, The Writer Began Penning His Own History of the World. First Published In 1922, A Short History of the World Presents a Ground-Breaking Study of the Civilisation from the Origins of the Earth, Spanning the Neolithic Era, The Rise of Judaism, The Golden Age of Athens, Christ's Life, The Great Discovery of America to the Consequences of World War I.

Inspired by Wells'S the Outline of History (1919) A Work in Three Volumes, Beginning with Prehistory and Following the World's Significant Events Through World War I this Condensed Work Chronicles the Physical, Intellectual and Spiritual Evolution of The Human Race. Wells Adopts a Darwinian Approach and Avoids Presenting History Within a Politicised Framework. Passionately Told, A Short History of the World Remains an Evergreen Classic.

Short History of the World by H.G. Wells

✔ Premium Quality with Paperback

✔ Approved by Historical Literary Teachers

✔ Masterpiece of Human History Classic Literature

✔ From Imagination to Reality

✔ Response to Post-War Discontent

✔ History that Spans the Ages

✔ Key Moments Brought to Life`,
  },
  {
    id: "11",
    category: "History Book",
    title:
      "PMF IAS Ancient and Medieval Indian History for UPSC, State PCS & Other Competitive Exams",
    img: "../images/historybook4.png",
    Price: "200",
    Description: `Key Highlights of the Book:

✔ Experience History, Don’t Just Read It - The book immerses you in historical moments, making learning engaging and vivid.

✔ Conceptual Learning, Not Rote Memorization - Content is structured to help you understand rather than just memorize facts.

✔ Infographics, Timelines & Pictures - Visual aids enhance recall and retention of key events and concepts.

✔ Previous Year & Practice Questions - Every chapter includes PYQs and practice questions to highlight its relevance and test your understanding.

✔ Tailored for UPSC & State PCS - Designed specifically for Prelims and Mains aspirants, covering the exam's analytical approach.`,
  },
  {
    id: "12",
    category: "History Book",
    title:
      "A History of Ancient and Early Medieval India |for UPSC | Civil Services Exam | State Administrative exams | Stone Age to the 12th Century| by Upinder Singh, 2nd Edition",
    img: "../images/historybook5.png",
    Price: "259",
    Description: `Established as a classic in its first edition the second edition of Upinder Singh’s A History of Ancient and Early Medieval India incorporates the latest discoveries research and insights in the field. Drawing on a vast array of textual archaeological and visual sources it weaves together discussions of politics economy society religion philosophy art and ideas into a seamless narrative.

The book reveals the complex and dynamic history of the regions of the subcontinent across millennia by focusing on macro-level changes as well the everyday lives of ordinary people. Widely acclaimed as an excellent introduction to the subject for general readers as well as the most comprehensive and authoritative textbook for undergraduate and postgraduate students this classic maintains its reputation of offering a lucid detailed and balanced exposition equipping readers with skills to critically assess historical evidence arguments and debates.

The book is a readers delight with excerpts from original sources and a wealth of images and illustrations of Indias diverse and rich historical heritage making an exploration of the past a truly exciting journey.

Features –

💡Beautifully designed Chapter Openers that encourage readers to ask questions about the period Chapter Outline at the beginning of chapters provides an overview of the organization of the chapter.

💡Key Concepts helps in understanding the conceptual vocabulary used by historians and draws attention to the inherent interdisciplinary nature of history

💡Primary Sources provide with descriptions and illustrations of archaeological source material interesting information about textual sources and their authors translated excerpts from ancient texts and inscriptions and discussions of visual sources.

💡Further Discussion boxes reveal the multi- layered nature of our past and encourage readers to think more deeply about a variety of historical themes and issues Recent Discoveries direct attention to some of these exciting discoveries the people who made them and their impact on our understanding of India’s ancient past.

💡New Directions In Research boxes bridge the gap between readers and researchers by presenting samples of interesting new research and explaining their methodology and results in a clear and accessible way.

💡Visuals consist over 400 illustrations including maps photographs and drawings—that bring history alive.

💡Further Readings and the end of each chapter encourage you to read more extensively on various topics to deepen your understanding of the subconti- nental past Cross references are provided in the margins indicate relevant page numbers.

💡Diacritic marks (Sanskrit and Tamil) have been provided at the end of the book to help you navigate through academic writings.`,
  },
  {
    id: "13",
    category: "History Book",
    title:
      "The People of the Indus: A Graphic Narrative on the Rise and Fall of the Harappan Civilization",
    img: "../images/historybook6.png",
    Price: "190",
    Description:
      "Who were the people of the Indus? Why didn't they build pyramids like the Egyptians? And ultimately what happened to them? Supported by extensive research from a leading Indus archaeologist, this graphic novel seeks answers to precisely these questions. It is not history in the form of a dull record of dates and events but a beautifully illustrated glimpse into the lives of the people of the Indus civilization, dating all the way back to 3200 BCE. The People of the Indus is a rare account of how one of the most unique and enigmatic civilizations of the ancient world changed the course of human history. It is sure to enthral young adults and older readers alike.",
  },
  {
    id: "14",
    category: "History Book",
    title:
      "Ancient and Medieval Indian History (English) for UPSC CSE 2025 by Poonam Dalal Dahiya (IPS) | 3rd edition (latest) | Civil Services Exam - Prelims, Mains and Interview | State PSCs exams/ PCS exams",
    img: "../images/historybook7.png",
    Price: "400",
    Description: `Combining storytelling and historical analysis, Ancient and Medieval India by Poonam Dalal Dahiya reveals India’s fascinating heritage, covering all important aspects meant for the aspirants of the Union Public Service Commission as well as various state public service examinations. This edition has been updated to assimilate latest data, information, questions, figures and maps in all the topics pertinent to the civil service examinations. Moreover, the book also consists of numerous chapter-wise practice questions, making it user-friendly and enhancing the aspirant’s preparation. The book comes in bi-colour with highlighted key words along with two detachable pluck-out charts on ancient and medieval India; ideal for long-term information retention and complete revision at a glance.
Salient Features:

1. Covers the complete UPSC and State Service Examinations syllabus.

2. Written in an easy-to-grasp and lucid manner.

3. Updated questions, facts, pictures, flowcharts and maps added for better clarity.

4. Two detachable pluck-out charts on ancient and medieval India for easy and instant pre-examination revision.

5. In-depth coverage of Bhakti and Sufi movements in accordance with the UPSC exam pattern.

6. Improved coverage of important topics like Buddhism and Jainism.

7. Latest preliminary and mains examination questions added in each chapter.`,
  },

  {
    id: "15",
    category: "Science Fiction",
    title: "The sanctum key: A glimpse of God from the shoulders of science",
    img: "../images/sciencefiction1.png",
    Price: "300",
    Description: `For two thousand years, two secret societies have fought to control the Sanctum Key, a source of unimaginable power. One seeks to unleash its dangerous secrets, while the other will stop at nothing to keep it hidden.
When a high-stakes experiment at the Satyendra Nath Bose Energy Research Center goes disastrously wrong, a group of unlikely heroes must race against time to stop a disaster that could tear the world apart.
Meanwhile, a forgotten genius in the past uncovers a deadly secret that could save or doom humanity. As the boundaries between myth and reality blur, only one question remains: Can the Sanctum Key's power be controlled, or will it destroy everything?`,
  },
  {
    id: "16",
    category: "Science Fiction",
    title: "The Theory Of Everything",
    img: "../images/sciencefiction2.png",
    Price: "800",
    Description: `Seven lectures by the brilliant theoretical physicist have been compiled into this book to try to explain to the common man, the complex problems of mathematics and the question that has been gripped everyone all for centuries, the theory of existence. Undeniably intelligent, witty and childlike in his explanations, the narrator describes every detail about the beginning of the universe. He describes what a theory that can state the initiation of everything would encompass. Ideologies about the universe by Aristotle, Augustine, Hubble, Newton and Einstein have all been briefly introduced to the reader. Black holes and Big Bang has been explained in an unsophisticated manner for anyone to understand. All these events and individual theories may be strung together to create a theory of the origin of everything and the author strongly believes that the origin might not necessarily be from a singular event. He advocates the idea of a multi-dimensional origin with a no-boundary condition to remain true to the theories of modern physics and quantum physics. The book provides a clear view of the world through Stephen’s mind where he respectfully dismisses the belief that the Universe conforms by a supernatural and all-powerful entity. About the Author Stephen Hawking: An English cosmologist, theoretical physicist, author as well as the Director of Research at the Centre for Theoretical Cosmology under the University of Cambridge, Stephen Hawking is a scholar with more than a dozen of honorary degrees. In was in 1963 that Stephen Hawking contracted a rare motor neuron disorder which gave him just two years to live, yet he went to Cambridge to become what he is today.`,
  },
  {
    id: "17",
    category: "Science Fiction",
    title: "Journey To The Centre of The Earth",
    img: "../images/sciencefiction3.png",
    Price: "600",
    Description: `Embark on a thrilling subterranean expedition with Journey to the Centre of the Earth by Jules Verne. Join Professor Lidenbrock and his companions as they navigate uncharted depths, encounter ancient wonders, and face unimaginable challenges in this timeless adventure classic.

An epic subterranean adventure!

Jules Verne's captivating tale of exploration and discovery
Unforgettable journey to the depths of the Earth's core
Engaging characters and vivid descriptions bring the underground world to life
A perfect blend of science, adventure, and imagination
A must-read for fans of thrilling escapades and wondrous landscapes`,
  },
  {
    id: "18",
    category: "Science Fiction",
    title: "The Time Machine",
    img: "../images/sciencefiction4.png",
    Price: "700",
    Description: `Embark on a captivating adventure with H.G. Wells' The Time Machine. Witness humanity's future, explore the depths of time, and ponder on profound questions. This unabridged edition guarantees an immersive experience.

A timeless journey through time!
Pioneering science fiction classic by H.G. Wells
Unforgettable journey through space
Encounters with future civilizations
Thought-provoking exploration of society and human nature
Unabridged edition for an authentic reading experience`,
  },
  {
    id: "19",
    category: "Science Fiction",
    title:
      "Relativity: The Special And The General Theory by Albert Einstein | Concepts of Physics, Relativity, General Relativity & Quantum Mechanics | Conceptual Physics, University Physics & Calculus Core ",
    img: "../images/sciencefiction5.png",
    Price: "500",
    Description: `Are you ready to delve into one of the most groundbreaking scientific treatises of all time? Albert Einstein's Relativity offers an unparalleled exploration of the principles that have revolutionized our understanding of the universe. This seminal work is a cornerstone for anyone passionate about conceptual physics and the theory of relativity.

Here’s Why You Need This Classic:

Master the Fundamentals of Physics: Einstein’s Relativity is obviously a foundational text in science for anyone who wants to improve their conceptual physics, calculus core principles, or their scientific thinking in general. It offers deep insights into the theory of relativity, making complex concepts accessible and understandable. Whether you’re a student of university physics or an enthusiast, this book is an essential resource for scientific minds.

Explore Advanced Topics: This treatise delves into sophisticated subjects that fall under the special theory of relativity, such as time dilation and simultaneity, or the general theory, such as the curvature of space time, the equivalence principle, or geodesics. Whether you enjoy studying quantum physics problems, classical mechanics such as the three body problem, you will find this book to be a great addition to your scientific knowledge.

Expand Your Scientific Horizons: Gain a better understanding of the world through this scientific text that is like a predecessor to the theory of everything. Explore the connections between Einstein’s work and other pivotal texts like Stephen Hawking’s Brief History of Time or Feynman Lectures on Physics and Six Easy Pieces by Richard Feynman. This book bridges the gap between general science and specialized fields, offering a holistic view of the progress in science, and how we think of the universe.

Enhance Your Mathematical Understanding: Einstein’s detailed exploration of relativity includes profound mathematical insights, making it an excellent companion for those interested in excursions in mathematics. If you enjoy reading books like Conceptual Physics by Paul G Hewitt, this is an excellent classic to develop your mathematical problem-solving skills.

Understand Space and General Relativity: Einstein’s pioneering work on general relativity and its implications for our understanding of space is unmatched. This book provides a thorough overview of these concepts, allowing readers to appreciate the elegance and complexity of the universe.

Equip yourself with the knowledge that has shaped modern physics. With Relativity by Einstein, you'll join the ranks of those who have unlocked the secrets of the universe. Dive into this timeless work and transform your understanding of the world and the universe.`,
  },
  {
    id: "20",
    category: "Science Fiction",
    title: "Science and Magic - The Search Begins",
    img: "../images/sciencefiction6.png",
    Price: "100",
    Description: `In a world where science is everything, humans rule the universe, and people no longer believe in magic. An earthling, Sam, who grew up believing that he is an orphan, dreams of finding true magic and the answer to life. His admission into Volgarth, a mysterious institution in the far-away planet of Tiron, brought hope into his life. He will meet new friends there; new territories and magical lore will be explored. But magic brings with it many mysteries and dangerous secrets. Strange secrets are associated with Sam and his past and it makes him special. but only if he can figure out what they are.`,
  },
  {
    id: "21",
    category: "Science Fiction",
    title: "Spaceboy ",
    img: "../images/sciencefiction7.png",
    Price: "290",
    Description: `Go back to the Space Race with No.1 bestselling author David Walliams for a breathless cinematic adventure full of mystery, action, laughs and surprises – and a secret that could change the course of history…

America. The 1960s.

Stuck on a remote farm with her awful aunt, twelve-year-old orphan Ruth spends every night gazing at the stars, dreaming of adventure.

One night she spots a flying saucer blazing across the sky… before crash-landing in a field. When the spaceship opens and reveals a mysterious alien, all Ruth’s dreams come true.

But does this visitor from another planet have a giant secret?

Spaceboy is a hilarious and action-packed tale for readers in any solar system.`,
  },

  {
    id: "22",
    category: "Adventure Fiction",
    title:
      "The Adventures of Sherlock Holmes Illustrated Abridged Children Classics English Novel with Review Questions Hardback",
    img: "../images/adventurefiction1.png",
    Price: "270",
    Description:
      "Suspense, intrigue, and mystery! Twelve stories with twelve different plots make The Adventures of Sherlock Holmes a must read for all those who love detective stories. Set in the backdrop of 19th century England, Sherlock Holmes and his friend Dr. Watson solve some of the most fascinating cases, from jewel robbery to murder. Join Holmes and Watson as they journey across the most puzzling mysteries of their lives.",
  },
  {
    id: "23",
    category: "Adventure Fiction",
    title: "The Adventure Classics Collection (Set of 4 Books)",
    img: "../images/adventurefiction2.png",
    Price: "370",
    Description: `Hop on a literary voyage into the heart of adventure, discovery, and the human spirit. Daniel Defoe's Robinson Crusoe tells the riveting tale of survival on a deserted island, while Robert Louis Stevenson's Treasure Island takes readers on a thrilling quest for buried riches. Jonathan Swift's satirical masterpiece, Gulliver's Travels, offers a fantastical journey through strange lands, and Johann David Wyss' The Swiss Family Robinson unfolds an epic tale of resourcefulness on a deserted island. The Adventure Classics Collection brings together all these timeless literary treasures.

“Every man desires to live long, but no man wishes to be old.” - Jonathan Swift

Offers a variety of genres, including survival, adventure, satire, and family-centered tales.
Inspirational stories that showcase the resilience and perseverance of the human spirit.
Provides thrilling quests for buried treasures, satisfying the desire for escapism and excitement.
The collection brings together iconic works of literature that have contributed significantly to the literary canon.
Suitable for book clubs or group discussions.`,
  },
  {
    id: "24",
    category: "Adventure Fiction",
    title:
      "365 Adventure Stories | Thrilling Tales of Heroes, Quests & Exploration for Kids | Daily Storytime Packed with Action & Fun | Illustrated Bedtime Storybook",
    img: "../images/adventurefiction3.png",
    Price: "570",
    Description:
      "Do you dream of slaying monsters, finding buried treasure and hanging out with pirates? If you do, this book is perfect for you. Take a swig of courage, get your sword and shield ready and brush up on your map-reading skills. You're about to embark on a new adventure and fight against new villains with every story. Hurry, don't waste time! Start reading and let your adventures begin.",
  },
  {
    id: "25",
    category: "Adventure Fiction",
    title: "The Island of Adventure (The Adventure Series, 1)",
    img: "../images/adventurefiction4.png",
    Price: "390",
    Description:
      "The Island of Adventure is the first thrilling instalment in the Adventure series by Enid Blyton, one of the best-loved children's writers of all time.For Philip, Dinah, Lucy-Ann, Jack and Kiki the parrot, the summer holidays in Cornwall are everything they'd hoped for. Until they begin to realize that something very sinister is taking place on the mysterious Isle of Gloom - where a dangerous adventure awaits them in the abandoned copper mines and secret tunnels beneath the sea.",
  },
  {
    id: "26",
    category: "Adventure Fiction",
    title:
      "Adventures of Tom Sawyer (Abridged Classics) (Illustrated) - Novel - Story Book for Kids - English Stories for Children - Age 6+ - Ideal for Classroom Reading",
    img: "../images/adventurefiction5.png",
    Price: "80",
    Description:
      "Little Tom Sawyer is a mischievous boy who enjoys daring escapades with his friends. From late-night ventures into the graveyard to living like pirates, the possibilities for adventure are endless. The story captures the essence of childhood and the complexities of growing up, making it a beloved American classic.",
  },
  {
    id: "27",
    category: "Adventure Fiction",
    title:
      "The Adventures of Tom Sawyer : llustrated Abridged Children Classic English Novel with Review Questions",
    img: "../images/adventurefiction6.png",
    Price: "90",
    Description:
      "Tom, a mischievous young boy, lives with his Aunt Polly and younger brother Sid. He is famous for his pranks and for being a troublemaker. He has an uncanny ability to get out of tight situations with whatever means are at hand. Things take an untoward turn when Tom and his friend Huckleberry Finn sneak into a graveyard one night and witness a murder. What follows are a series of adventures—fearsome, hilarious and inspiring.",
  },
  {
    id: "28",
    category: "Adventure Fiction",
    title:
      "The Magical Mission to Mars: Exciting Space Adventure Story Book for 6-8 Year Old Kids with Vibrant Illustrations & Inspiring Lessons",
    img: "../images/adventurefiction7.png",
    Price: "230",
    Description: `Embark on an interstellar journey with "The Magical Mission to Mars", the perfect story book for 6-8 year old boys and girls who dream of space and beyond. This hardcover children's book, crafted with incredible AI illustrations, takes young readers on an exciting adventure with Anay, a brave young boy from India with aspirations of becoming an astronaut.
Anay's quest leads him to Mars, where he encounters a friendly alien civilization. This extraordinary meeting between a boy and Martians is not just a thrilling narrative but also a source of inspiration, encouraging kids to pursue knowledge and believe in their dreams. Ideal for children who love stories about space exploration, this book is a must-have for any young reader's library.

Key Features:
- A captivating space adventure that sparks imagination and curiosity.
- Educational content that introduces children to the wonders of the cosmos.
- Glossary of difficult words to enhance vocabulary and understanding.
- A story that promotes big dreams and the pursuit of ambitions.
- A celebration of human creativity and technology through storytelling.

About the Author:
Ashima Mathur, a Pearl Academy graduate, weaves her storytelling magic by drawing inspiration from literary giants who have shaped the landscape of children's literature. Influenced J.K. Rowling, Roald Dahl, Ross Welford, and Dr. Seuss, Ashima's passion for design and storytelling comes to life in "The Magical Mission to Mars." Her innovative use of AI in illustration further distinguishes her work, offering a fresh and engaging reading experience.

Don't miss out on this book ideal for 6+ year olds, 7 year olds, and 8 year old boys and girls that has been extensively covered and appreciated in the media. Add 'The Magical Mission to Mars' to your cart today and let your child discover the joy of reading and the power of dreams!`,
  },
  {
    id: "29",
    category: "Horror",
    title: "Ghosts of The Silent Hills: Stories based on true hauntings",
    img: "../images/horror1.png",
    Price: "220",
    Description:
      "The dead do not rest till they get what they want. You have arrived in the hills. In here, you are surrounded by dense, menacing forests, enveloped in a deadly silence... You never know what lurks here in the Cold, dark night. Do not walk alone after sunset in the hills. A beautiful woman in white haunts the Lonely pathways, looking to enchant and ensnare men... All the people who died in accidents here... They say you hear their screams at night. And the deserted lodges sitting amidst lush greenery and calm streams... Spirits lie in wait here, ready to prey on the living. There are sceptics who did not heed these warnings. They tried to rationalize what they saw, what they felt. But when they came face to face with the beings that they believed didn’t exist, they couldn’t run away anymore... Ghosts of the silent hills is a collection that will make your nights a little scarier, encompassing the very best spine-chilling stories based on true hauntings.",
  },
  {
    id: "30",
    category: "Horror",
    title:
      "Greatest Horror Stories from Around the World (Deluxe Hardbound Edition) ",
    img: "../images/horror2.png",
    Price: "320",
    Description: `Greatest Horror Stories from Around the World is a spine-chilling anthology featuring classic tales of terror from literary giants like Arthur Conan Doyle, Edgar Allan Poe, H. P. Lovecraft, Guy de Maupassant, and more. From psychological suspense to supernatural horror, this collection delves into the darkest corners of human fear, making it a must-have for horror enthusiasts and anyone eager to explore the genre’s timeless and diverse traditions.

Tales that will linger long after the last page is turned!

Offers a taste of the world's best horror literature.
The stories explore universal fears that resonate across cultures and time periods.
Includes a variety of short stories like The Horror of the Heights, The Tell-Tale Heart, The Cats of Ulthar, and more.
Carefully selected stories that represent different periods, regions and styles.
The stories explore deep psychological and existential themes that provoke thought and introspection.`,
  },
  {
    id: "31",
    category: "Horror",
    title: "The Canterville Ghost ",
    img: "../images/horror3.png",
    Price: "40",
    Description: `The Canterville Ghost is a classic tale by Oscar Wilde, first published in 1887. A delightful read for all ages, the story follows the Otis family as they move into Canterville Chase, a haunted mansion in England, and encounter the mischievous ghost that haunts the house. This charming tale offers a unique blend of wit, satire, and heartfelt moments.

Blends comedy and the supernatural in a unique way.
An engaging story of a ghost's attempts to scare new residents.
Witty and satirical commentary on societal norms and expectations.
Features vividly drawn and memorable characters.
A must-read for fans of Wilde’s works and lovers of classic literature.`,
  },
  {
    id: "32",
    category: "Horror",
    title:
      "That Night: Four Friends, Twenty Years, One Haunting Secret—A Twisted Thriller of Guilt, Betrayal, and Revenge ",
    img: "../images/horror4.png",
    Price: "620",
    Description:
      "Natasha, Riya, Anjali and Katherine were best friends in college - Each different from the other yet inseparable - until that night. It was the night that began with a bottle of whisky and a game of Ouija but ended with the death of Sania, their unlikeable hostel mate. The friends vowed never to discuss that fateful night, a pact that had kept their friendship and guilt dormant for the last twenty years. But now, someone has begun to mess with them, threatening to reveal the truth that only Sania knew. Is it a hacker playing on their guilt or has sania's ghost really returned to avenge her death? As the faceless enemy closes in on them, the friends come together once again to recount what really happened that night. But when the story is retold by each of them, the pieces don't fit. Because none of them is telling the whole truth. that night is a dark, twisted tale of friendship and betrayal that draws you in and confounds you at every turn.",
  },
  {
    id: "33",
    category: "Horror",
    title: "Haunting Of Delhi City",
    img: "../images/horror5.png",
    Price: "370",
    Description: `You know Delhi for its rich cultural tapestry, history and monuments. You love it for its food--kebabs, chole-kulche, golgappe and chaat.

But do you know about the dark shadows that lurk in its all-too-familiar haunts--the arcades of Connaught Place, the gullies of Mehrauli, the lawns of Lutyens' Delhi, or the pillars and arches of the tombs in Hauz Khas?

The stories in The Haunting of Delhi City are set in a Delhi we think we know well, but don't. This is a Delhi that reveals the presence of the supernatural at every corner-ghosts as real to us in stories as they are in our imagination. Exquisitely chilling, each of these tales holds a piece of the city and its people-especially the ghosts.

Oh, these are just stories, you say. But are they?

Come, have a read ... if you dare.`,
  },
  {
    id: "34",
    category: "Horror",
    title: "The Wind on the Haunted Hill",
    img: "../images/horror6.png",
    Price: "470",
    Description:
      "A gorgeously illustrated spooky story for young readers by India's most-loved author Ruskin Bond.A gorgeous full-colour chapter book, ideal for young readers (ages 6 and up) with its large font, eye-catching illustrations and easy languagePerfect book to read along with and also as a read-it-yourselfA beautiful introduction to the works of Ruskin Bond for childrenThe wild wind pushes open windows, chokes chimneys and blows away clothes as it huffs and puffs over the village by Haunted Hill, where Usha, Suresh and Binya live. It's even more mighty the day Usha is on her way back from the bazaar. A deep rumble echoes down the slope and a sudden flash of lightning lights up the valley as fat drops come raining down.In search of shelter, Usha rushes into the ruins on Haunted Hill, grim and creepy against the dark sky. Inside, the tin roof groans, strange shadows are thrown against the walls and little Usha shivers with fear. For she isn't alone.A gritty, hair-raising story about friendship, courage and survival, this stunning edition will introduce another lot of young readers to the magic of Ruskin Bond's craft.Other popular books in the series include The Cherry Tree, Ranji the Music Maker, Earthquake and The Day Grandfather Tickled a Tiger.",
  },
  {
    id: "35",
    category: "Horror",
    title: "The Game of Death",
    img: "../images/horror7.png",
    Price: "560",
    Description: `The Game of Death follows teenager Aliza on a chilling quest after receiving a mysterious diary from her vanished classmate, Amrit. As she uncovers sinister truths and eerie rituals, Aliza is drawn into a dangerous web of lies and secrets. With the help of Inspector Selva, she must navigate a conspiracy that could cost her life. But as the truth inches closer, Aliza begins to wonder—who can she trust when everyone seems to have their own agenda?

The truth hides in the shadows, and the game is far from over!

A suspenseful, twist-filled journey that will keep one on edge as Aliza uncovers a web of lies and sinister truths.
Combines elements of mystery, suspense and psychological tension, making it an unputdownable read.
The unsettling rituals and a mysterious figure heightens the suspense.
Features a riveting investigation led by Aliza and Inspector Selva.
Vivid descriptions and suspenseful settings in a world where danger lurks around every corner.`,
  },

  {
    id: "36",
    category: "Fantasy",
    title: "The Name of the Wind",
    img: "../images/fantasy1.png",
    Price: "80",
    Description: `Discover #1 New York Times-bestselling Patrick Rothfuss' epic fantasy series, The Kingkiller Chronicle. "I just love the world of Patrick Rothfuss." -Lin-Manuel Miranda OVER 1 MILLION COPIES SOLD! DAY ONE: THE NAME OF THE WIND My name is Kvothe. I have stolen princesses back from sleeping barrow kings. I burned down the town of Trebon. I have spent the night with Felurian and left with both my sanity and my life. I was expelled from the University at a younger age than most people are allowed in. I tread paths by moonlight that others fear to speak of during day. I have talked to Gods, loved women, and written songs that make the minstrels weep. You may have heard of me. So begins a tale unequaled in fantasy literature-the story of a hero told in his own voice. It is a tale of sorrow, a tale of survival, a tale of one man's search for meaning in his universe, and how that search, and the indomitable will that drove it, gave birth to a legend.`,
  },
  {
    id: "37",
    category: "Fantasy",
    title: "They Bloom at Night",
    img: "../images/fantasy2.png",
    Price: "390",
    Description: `The author of the New York Times bestselling horror phenomenon She Is a Haunting is back with a novel about the monsters that swim beneath us . . . and live within us.
Since the hurricane, the town of Mercy, Louisiana has been overtaken by a strange red algae bloom. Noon and her mother have carved out a life in the wreckage, trawling for the mutated wildlife that lurks in the water and trading it to the corrupt harbormaster. When she's focused on survival, Noon doesn't have to cope with what happened to her at the Cove or the monster itching at her skin.
Mercy has never been a safe place, but it's getting worse. People are disappearing, and the only clues as to why are whispers of underwater shadows and warnings to never answer the knocks at night. When the harbormaster demands she capture the creature that's been drowning residents, Noon finds a reluctant ally in his daughter Covey. And as the next storm approaches, the two set off to find what's haunting Mercy. After all, Noon is no stranger to monsters . . .`,
  },
  {
    id: "38",
    category: "Fantasy",
    title: "What Wakes the Bells",
    img: "../images/fantasy3.png",
    Price: "700",
    Description: `Inspired by an ominous Prague legend, What Wakes the Bells is a lavish gothic fantasy by debut author Elle Tesch that is perfect for fans of Adalyn Grace, Margaret Rogerson, and V.E. Schwab.

Built by long-gone Saints, the city of Vaiwyn lives and breathes and bleeds. As a Keeper, Mina knows better than most what her care of Vaiwyn’s bells means for the sentient city. It’s the Strauss family’s thousand-year legacy―prevent the Vespers from ringing, or they will awake a slumbering evil.

One afternoon, to Mina's horror, her bell peals thirteen times, shattering the city’s tenuous peace. With so much of the city's history and lore lost in a long-ago disaster, no one knows the danger that has been unleashed―until the city begins to fight back. As the sun sets, stone gargoyles and bronze statues tear away from their buildings and plinths to hunt people through the streets. Trapped in Mina’s bell, the soul of a twisted and power-hungry Saint festered. Now free of his prison, he hides behind the face of one of Vaiwyn’s citizens, corrupting the city and turning it on itself.

As the death toll rises, the only chance Mina has to stop the destruction and horrific killings is finding and destroying the Saint’s host. Everyone is a suspect, including Mina's closest loved ones. She will have to decide how far she’ll go to save her city―and who she’s willing to kill to do it.`,
  },
  {
    id: "39",
    category: "Fantasy",
    title: "When the Moon Hits Your Eye",
    img: "../images/fantasy4.png",
    Price: "170",
    Description: `New York Times bestseller John Scalzi flies you to the moon with his most fantastic tale to date: When the Moon Hits Your Eye

The moon has turned into cheese.

Now humanity has to deal with it.

For some it’s an opportunity. For others it’s a moment to question their faith: In God, in science, in everything. Still others try to keep the world running in the face of absurdity and uncertainty. And then there are the billions looking to the sky and wondering how a thing that was always just there is now... something absolutely impossible.

Astronauts and billionaires, comedians and bank executives, professors and presidents, teenagers and terminal patients at the end of their lives -- over the length of an entire lunar cycle, each get their moment in the moonlight. To panic, to plan, to wonder and to pray, to laugh and to grieve. All in a kaleidoscopic novel that goes all the places you’d expect, and then to so many places you wouldn’t.

It’s a wild moonage daydream. Ride this rocket.`,
  },
  {
    id: "40",
    category: "Fantasy",
    title: "Fan Service",
    img: "../images/fantasy5.png",
    Price: "470",
    Description: `The truth is stranger than fan fiction in the new sexy, paranormal romcom from the bestselling author of The Roommate and The Intimacy Experiment.

The only place small-town outcast Alex Lawson fits in is the online fan forum she built for Arcane, a long-running werewolf detective show. Her dedication to archiving fictional supernatural lore made her Internet-famous, even if she harbors a secret disdain for the show's star, Devin Ashwood. (Never meet your heroes - sometimes they turn out to be The Worst.)

Ever since his show went off the air, Devin and his career have spiralled, but waking up naked in the woods outside his LA home with no memory of the night before is a new low. It must have been a coincidence that the once-in-a-century Wolf Blood Moon crested last night. The claws, fangs, and howling are a little more difficult to explain away. Desperate for answers, Devin finds Alex - the closest thing to an expert that exists. If only he could convince her to stop hating his guts long enough to help . . .

Once he makes her an offer she can't refuse, these reluctant allies lower their guards trying to wrangle his inner beast. Unfortunately, getting up close and personal quickly comes back to bite them.`,
  },
  {
    id: "41",
    category: "Fantasy",
    title: "Wind and Truth",
    img: "../images/fantasy6.png",
    Price: "600",
    Description: `La esperada y explosiva conclusión del primer arco de la saga El Archivo de las Tormentas, obra cumbre de Brandon Sanderson, con más de diez millones de lectores en todo el mundo.

Dalinar Kholin desafió al malvado dios Odium a un duelo de campeones en el que se decidirá el futuro de Roshar. Los Caballeros Radiantes solo tienen diez días para prepararse... y la repentina ascensión del taimado e implacable Taravangian al puesto de Odium lo ha sumido todo en una tremenda confusión.

La lucha desesperada prosigue simultáneamente a lo largo y ancho del mundo: Adolin en Azimir, Sigzil y Venli en las Llanuras Quebradas y Jasnah en Ciudad Thaylen. El exasesino Seth deberá purgar Shinovar, su tierra natal, de la oscura influencia de los Deshechos. Lo acompaña Kaladin, que afronta una nueva batalla ayudando a Seth a combatir sus propios demonios... y tendrá que hacer lo mismo con Ishar, el demente Heraldo del Todopoderoso.

Al mismo tiempo, Shallan, Renarin y Rlain se esfuerzan en desentrañar el misterio que hay tras la Deshecha Ba-Ado-Mishram, el de qué papel tuvo en la esclavización de la especie cantora y en el hecho de que los antiguos Caballeros Radiantes mataran a sus spren. Y Dalinar y Navani buscan una ventaja contra el campeón de Odium que solo puede hallarse en el Reino Espiritual, donde el recuerdo y la posibilidad se combinan en el caos. El destino de todo el Cosmere pende de un hilo.

ENGLISH DESCRIPTION

The long-awaited explosive climax to the first arc of the #1 New York Times bestselling Stormlight Archive―the iconic epic fantasy masterpiece that has sold more than 10 million copies, from acclaimed bestselling author Brandon Sanderson.

Dalinar Kholin challenged the evil god Odium to a contest of champions with the future of Roshar on the line. The Knights Radiant have only ten days to prepare―and the sudden ascension of the crafty and ruthless Taravangian to take Odium’s place has thrown everything into disarray.

Desperate fighting continues simultaneously worldwide―Adolin in Azir, Sigzil and Venli at the Shattered Plains, and Jasnah in Thaylenah. The former assassin, Szeth, must cleanse his homeland of Shinovar from the dark influence of the Unmade. He is accompanied by Kaladin, who faces a new battle helping Szeth fight his own demons . . . and who must do the same for the insane Herald of the Almighty, Ishar.

At the same time, Shallan, Renarin, and Rlain work to unravel the mystery behind the Unmade Ba-Ado-Mishram and her involvement in the enslavement of the singer race and in the ancient Knights Radiant killing their spren. And Dalinar and Navani seek an edge against Odium’s champion that can be found only in the Spiritual Realm, where memory and possibility combine in chaos. The fate of the entire Cosmere hangs in the balance.`,
  },
  {
    id: "42",
    category: "Fantasy",
    title: "Heat of the Everflame",
    img: "../images/fantasy7.png",
    Price: "890",
    Description: `The war has begun. Both sides demand Diem’s allegiance—or her death.

After her disastrous coronation, Diem finds herself at the center of the conflict between the Descended and the Guardians. With her newfound friends and the man she’s falling for on one side, and the mortals she has vowed to protect on the other, Diem must walk a careful line to save the people she loves… even from each other.

The mystery of her unusual heritage begins to unravel, sending Diem and Luther on an unexpected journey across the realms. The answers may hold the key to winning the war, but finding them will require her to face painful truths about her mother, her bloodline, and her fate.

Meanwhile, the Crowns have set Diem in their sights. Some could be her greatest allies—while others want her dead. To end their oppressive reign, Diem must sort friend from foe and risk it all to build an army of her own.

But a powerful figure in the north has plans that could change everything...

Heat of the Everflame is the third book in The Kindred's Curse Saga, a four-book epic fantasy romance series that follows our fiesty, bad*ss heroine Diem Bellator in her fight against injustice, her struggle to survive in a royal palace full of betrayal and intrigue, and her journey of self-discovery and finding true love. This slow burn, enemies-to-lovers series is perfect for fans of unique magic systems, dragons and other mythical creatures, angst and romantic tension, and hilarious banter. This book will appeal to fans of plot-heavy, character-driven romantasy such as A Court of Thorns and Roses, Throne of Glass, From Blood and Ash, Gild, Shadow & Bone, and The Serpent & the Wings of Night.`,
  },
];
module.exports = { booksarray };
