import LoginSignup from './Components/LoginSignup'
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from './Components/Home';
import Cart from './Components/Cart';
import Confirmation  from './Components/Confirmation';
import Orders from './Components/Orders';
function App() {

  return (
    <>
    <Router>
      <Routes>
      <Route path="/" element={<Home></Home>}></Route>
        <Route path='/home' element={<Home></Home>}></Route>
        <Route path='/home?user=${encodeURIComponent(emailFirstPart)}' element={<Home></Home>}></Route>
        <Route path="/login" element={<LoginSignup></LoginSignup>}></Route>
        <Route path="/logout" element={<Home></Home>}></Route>
        <Route path="/Addtocart" element={<Cart></Cart>}></Route>
        <Route path='/Addtocart?user=${encodeURIComponent(userloggedIn)}' element={<Cart></Cart>}></Route>
        <Route path='/ConfirmationPage' element={<Confirmation></Confirmation>}></Route>
        <Route path='/Orderhistory' element={<Orders></Orders>}></Route>
      </Routes>
    </Router>
    </>
  )
}

export default App
