import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import "../App.css";

export default function Cart() {
  const location = useLocation();
  const queryparams = new URLSearchParams(location.search);
  const userdetails = queryparams.get("user");
  const firstName = userdetails ? userdetails.split("@")[0] : "";
  const firstword = firstName.split("")[0];

  const [book, setBook] = useState(null);
  const [cartItems, setCartItems] = useState([]);
  const [databooks, setDatabooks] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const searchContainerRef = React.useRef(null);
  const showBookListContainerRef = React.useRef(null);
  const [isVisible, setIsVisible] = useState(true);


  useEffect(() => {
    document.title = "Shopping Cart";

    const fromStorage = JSON.parse(localStorage.getItem("selectedBook"));
    setBook(fromStorage);

    const userEmail = localStorage.getItem("Login Success");
    const storedCart = JSON.parse(localStorage.getItem(`cart_${userEmail}`)) || [];
    setCartItems(storedCart);

    fetchAllBooks();

    const handleClickOutside = (event) => {
      if (
        searchContainerRef.current &&
        !searchContainerRef.current.contains(event.target) &&
        showBookListContainerRef.current &&
        !showBookListContainerRef.current.contains(event.target)
      ) {
        setIsVisible(false);
      } else {
        setIsVisible(true);
      }
    };

    document.addEventListener("click", handleClickOutside);

    return () => {
      document.removeEventListener("click", handleClickOutside);
    };
  }, [location.state]);
  const fetchAllBooks = async () => {
    try {
      const urls = [
        "http://localhost:3000/getbooksdata",
        "http://localhost:3000/gethistorybookdata",
        "http://localhost:3000/getsciencebookdata",
        "http://localhost:3000/getadventurebookdata",
        "http://localhost:3000/gethorrorbookdata",
        "http://localhost:3000/getfantasybookdata",
      ];
      const allData = await Promise.all(urls.map((url) => fetch(url).then((res) => res.json())));
      setDatabooks(allData.flat());
    } catch (err) {
      console.error(err);
    }
  };

  const cartbtn = () => {
    const orderquantity = parseInt(document.querySelector("#orderquantity").value, 10);
    if (!book || isNaN(orderquantity)) return;

    const userEmail = localStorage.getItem("Login Success");
    if (!userEmail) {
      alert("User not logged in!");
      return;
    }

    const existingCart = JSON.parse(localStorage.getItem(`cart_${userEmail}`)) || [];

    const updatedBook = { ...book, quantity: orderquantity };

    const existingIndex = existingCart.findIndex((item) => item.title === updatedBook.title);

    if (existingIndex !== -1) {
      existingCart[existingIndex].quantity += orderquantity;
    } else {
      existingCart.push(updatedBook);
    }

    localStorage.setItem(`cart_${userEmail}`, JSON.stringify(existingCart));
    setCartItems(existingCart);

    const totalQuantity = existingCart.reduce((total, item) => total + item.quantity, 0);
    document.querySelector(".addeditems").innerText = totalQuantity;
  };

  const selectbook = (element) => {
    localStorage.setItem("selectedBook", JSON.stringify(element));
    const userloggedIn = localStorage.getItem("Login Success");
    setBook(element); // ✅ Set book in state to display immediately
    navigate(`/Addtocart?user=${encodeURIComponent(userloggedIn)}`);
  };

  const filteredBooks = databooks.filter((book) =>
    book.title.toLowerCase().includes(searchTerm.toLowerCase())
);
  const showdiv = () => {
    const ShoppingCart = document.querySelector(".ShoppingCart");
    const Outerdiv1 = document.querySelector(".Outerdiv1");
    const Outerdiv2 = document.querySelector(".Outerdiv2");
    const container1=document.querySelector('.container1');
    ShoppingCart.style.display = "block";
    Outerdiv1.style.display = "none";
    Outerdiv2.style.display = "none";
    container1.style.display="none";
    
    // ✅ Refresh cart from localStorage
    const userEmail = localStorage.getItem("Login Success");
    const storedCart =
      JSON.parse(localStorage.getItem(`cart_${userEmail}`)) || [];
    setCartItems(storedCart);
  };

  const updateQuantity = (index, delta) => {
    const updatedCart = [...cartItems];
    updatedCart[index].quantity += delta;

    if (updatedCart[index].quantity < 1) {
      updatedCart.splice(index, 1);
    }

    setCartItems(updatedCart);
    const userEmail = localStorage.getItem("Login Success");
    localStorage.setItem(`cart_${userEmail}`, JSON.stringify(updatedCart));

    const totalQuantity = updatedCart.reduce(
      (total, item) => total + item.quantity,
      0
    );
    document.querySelector(".addeditems").innerText = totalQuantity;
  };

  const navigate = useNavigate();
  const paybtn = () => {
    const buynowbtn = document.querySelector(".buynowbtn");
    const btn2 = document.querySelector(".btn2");
    buynowbtn.style.display = "none";
    btn2.style.display = "block";
    const date = new Date();
    const formatted = date.toLocaleDateString("en-GB", {
      day: "numeric",
      month: "long",
      year: "numeric",
    });

    const userEmail = localStorage.getItem("Login Success");
    const storedCart = JSON.parse(localStorage.getItem(`cart_${userEmail}`));

    setTimeout(() => {
      navigate(
        `/ConfirmationPage?user=${encodeURIComponent(
          userEmail
        )}&storedCart=${encodeURIComponent(
          JSON.stringify(storedCart)
        )}&formatted=${encodeURIComponent(formatted)}`
      );
    }, 2000);
  };
 useEffect(() => {
     const handleClickOutside = (event) => {
       if (
         searchContainerRef.current &&
         !searchContainerRef.current.contains(event.target) &&
         showBookListContainerRef.current &&
         !showBookListContainerRef.current.contains(event.target)
       ) {
         setIsVisible(false); // hide the book list
       } else {
         setIsVisible(true); // click inside → keep visible
       }
     };
   
     document.addEventListener("click", handleClickOutside);
     
     return () => {
       document.removeEventListener("click", handleClickOutside);
     };
   }, []);

   const redirectohome=()=>{
    const userloggedIn=localStorage.getItem("Login Success");
    navigate(`/home?user=${encodeURIComponent(userloggedIn)}`);
  }
  return (
    <div>
      <section>
        <nav>
          <div className="container1">
            <div className="container2">
            {userdetails?( <div className="container3" onClick={redirectohome}>
                <img
                  src="https://static-assets-web.flixcart.com/batman-returns/batman-returns/p/images/fkheaderlogo_exploreplus-44005d.svg"
                  width="200"
                  height="80"
                  title="Flipkart"
                />
              </div>):(
                <div className="container3">
                <img
                  src="https://static-assets-web.flixcart.com/batman-returns/batman-returns/p/images/fkheaderlogo_exploreplus-44005d.svg"
                  width="200"
                  height="80"
                  title="Flipkart"
                />
              </div>
              )}
             
              <div className="searchcontainer" ref={searchContainerRef}>
                <button id="searchbtn" className="_2iLD__" type="submit">
                  <svg
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <title>Search Icon</title>
                    <path
                      d="M10.5 18C14.6421 18 18 14.6421 18 10.5C18 6.35786 14.6421 3 10.5 3C6.35786 3 3 6.35786 3 10.5C3 14.6421 6.35786 18 10.5 18Z"
                      stroke="#717478"
                      strokeWidth="1.4"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                    <path
                      d="M16 16L21 21"
                      stroke="#717478"
                      strokeWidth="1.4"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </button>
                <input
                  className="searchinputbox" value={searchTerm} onChange={(e)=>setSearchTerm(e.target.value)}
                  placeholder="Search for Products,Brands and More"
                />
              </div>
              <div className="logincontainer">
                <li id="container4" className="nav-item dropdown">
                  <a
                    className="nav-link dropdown-toggle"
                    role="button"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  >
                    {firstword}{" "}
                  </a>
                  <ul className="dropdown-menu droplist">
                    <hr />
                    <li className="orderlist" onClick={showdiv}>
                      <a className="dropdown-item">
                        <img
                          className="SFnind"
                          src="https://static-assets-web.flixcart.com/batman-returns/batman-returns/p/images/orders-bfe8c4.svg"
                          alt="Orders"
                          width="24"
                          height="24"
                        />
                        &nbsp; Orders
                      </a>
                    </li>
                    <li className="logoutlist">
                      <img
                        src="../images/logout.svg"
                        className="logout"
                        alt="Logout"
                      />
                      <a className="dropdown-item" href="/logout">
                        Logout
                      </a>
                    </li>
                  </ul>
                </li>
              </div>
              <div className="container5" onClick={showdiv}>
                <span className="addeditems"></span>
                <img
                  src="https://static-assets-web.flixcart.com/batman-returns/batman-returns/p/images/header_cart-eed150.svg"
                  alt="Cart"
                  width="24"
                  height="24"
                />
                &nbsp;&nbsp;Cart
              </div>
            </div>
            <section>
        <div
          className="showbooklistcontainer"
          ref={showBookListContainerRef}
          id="booklist"
          style={{ display: isVisible ? "block" : "none" }}
        >
          {userdetails &&
            filteredBooks.map((element) => (
              <div style={{ marginTop: "2rem" }} key={element.id}>
                <ul>
                  <li className="booktitle" onClick={() => selectbook(element)}>
                    {element.title}
                  </li>
                </ul>
              </div>
            ))}
        </div>
      </section>
          </div>
        </nav>
      </section>

      <section>
      <section>
        <div className="Outerdiv1">
          <div>
            {book ? (
              <>
                <div className="div1">
                  <p>{book.title}</p>
                </div>
                <div className="innerdiv1">
                  <img
                    src={`/images/${book.img}`}
                    alt={book.title}
                    className="bookimage"
                  />
                </div>
                <div className="innerdiv2">
                  <div style={{ margin: "0.9rem", textAlign: "center" }}>
                    <div className="Bookdescription">{book.Description}</div>
                    <br />
                    <select name="orderquantity" id="orderquantity">
                      <option value="quantity">Quantity</option>
                      {[...Array(20)].map((_, i) => (
                        <option key={i + 1} value={i + 1}>
                          {i + 1}
                        </option>
                      ))}
                    </select>
                    <br />
                    <p className="bookprice">MRP: ₹{book.Price}</p>
                  </div>
                </div>
              </>
            ) : (
              <p>No book selected.</p>
            )}
          </div>
        </div>
      </section>
        <div className="Outerdiv2">
          <br />
          <br />
          <br />
          <button className="btn btn-warning stylebtn" onClick={cartbtn}>
            Add to Cart
          </button>
          <br />
          <br />
          <button className="btn btn-danger stylebtn" onClick={showdiv}>
            Buy Now
          </button>
        </div>
      </section>

      <section>
        <div className="ShoppingCart">
          <h1 className="text1">Shopping Cart</h1>
          <hr style={{ width: "17rem", marginLeft: "2.9rem" }} />
          <br />
          <br />
          <div className="showcartitems">
            {cartItems.length > 0 ? (
              <>
                {cartItems.map((item, index) => (
                  <div
                    key={index}
                    style={{ display: "flex", flexWrap: "wrap" }}
                  >
                    <div className="cartimg">
                      <img
                        src={`/images/${item.img}`}
                        alt={item.title}
                        className="bookimage"
                      />
                    </div>
                    <div className="carttitle">{item.title}</div>
                    <div className="cartprice">₹{item.Price}</div>
                    <div className="buttons">
                      <button
                        className="deleteimgbtn"
                        onClick={() => updateQuantity(index, -1)}
                      >
                        <img
                          src="../images/deletebtn.png"
                          alt="deletebutton"
                          className="dlbtn"
                        />
                      </button>
                      <div style={{ fontWeight: "bold", fontSize: "1.2rem" }}>
                        {item.quantity}
                      </div>
                      <button
                        className="incrementbtn"
                        onClick={() => updateQuantity(index, 1)}
                      >
                        +
                      </button>
                    </div>
                    <hr style={{ width: "88%", marginLeft: "5%" }} />
                  </div>
                ))}
                <div style={{ marginTop: "2rem", textAlign: "center" }}>
                  <div className="subtotal">
                    Subtotal: ₹
                    {cartItems.reduce(
                      (total, item) => total + item.Price * item.quantity,
                      0
                    )}
                  </div>
                  <div className="buynowbtn" onClick={paybtn}>
                    <button className="btn btn-warning btn1">
                      Proceed to checkout
                    </button>
                  </div>
                  <div className="btn2">
                    Please Wait<span className="dots"></span>
                  </div>
                </div>
              </>
            ) : (
              <h3 style={{ textAlign: "center", marginTop: "-3%" }}>
                No items in the Cart.
              </h3>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}
