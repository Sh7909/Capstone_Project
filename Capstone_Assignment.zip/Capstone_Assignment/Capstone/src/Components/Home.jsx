import React, { useState, useEffect, useRef } from "react";
import "../App.css";
import { useNavigate } from "react-router-dom";
import { useLocation } from "react-router-dom";
const Home = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const queryparams = new URLSearchParams(location.search);
  const userdetails = queryparams.get("user");
  const firstName = userdetails ? userdetails.split("@")[0] : "";
  const firstword = firstName.split("")[0];
  const [databook, setDatabook] = useState([]);
  const [databook2, setDatabook2] = useState([]);
  const [databook3, setDatabook3] = useState([]);
  const [databook4, setDatabook4] = useState([]);
  const [databook5, setDatabook5] = useState([]);
  const [databook6, setDatabook6] = useState([]);
  const [searchTerm,setSearchTerm]=useState("");
  const searchContainerRef = React.useRef(null);
const showBookListContainerRef = React.useRef(null);
const [isVisible, setIsVisible] = React.useState(true);

  const redirecttologinpage = () => {
    navigate("/login");
  };
  const checkloginstatus = () => {
    if (userdetails) {
      fetch("http://localhost:3000/getbooksdata")
        .then((res) => res.json())
        .then((data) => setDatabook(data))
        .catch((err) => console.error(err));
    }

    if (userdetails) {
      fetch("http://localhost:3000/gethistorybookdata")
        .then((res) => res.json())
        .then((element) => setDatabook2(element))
        .catch((err) => console.error(err));
    }

    if (userdetails) {
      fetch("http://localhost:3000/getsciencebookdata")
        .then((res) => res.json())
        .then((element) => setDatabook3(element))
        .catch((err) => console.error(err));
    }
    if (userdetails) {
      fetch("http://localhost:3000/getadventurebookdata")
        .then((res) => res.json())
        .then((element) => setDatabook4(element))
        .catch((err) => console.error(err));
    }
    if (userdetails) {
      fetch("http://localhost:3000/gethorrorbookdata")
        .then((res) => res.json())
        .then((element) => setDatabook5(element))
        .catch((err) => console.error(err));
    }
    if (userdetails) {
      fetch("http://localhost:3000/getfantasybookdata")
        .then((res) => res.json())
        .then((element) => setDatabook6(element))
        .catch((err) => console.error(err));
    }
  };
  const scrollRef1 = useRef();
  const scrollRef2 = useRef();
  const scrollRef3 = useRef();
  const scrollRef4 = useRef();
  const scrollRef5 = useRef();
  const scrollRef6 = useRef();

  const scrollLeft1 = () => {
    scrollRef1.current.scrollLeft -= 800;
  };
  const scrollRight1 = () => {
    scrollRef1.current.scrollLeft += 800;
  };
  const scrollLeft2 = () => {
    scrollRef2.current.scrollLeft -= 800;
  };
  const scrollRight2 = () => {
    scrollRef2.current.scrollLeft += 800;
  };
  const scrollLeft3 = () => {
    scrollRef3.current.scrollLeft -= 800;
  };
  const scrollRight3 = () => {
    scrollRef3.current.scrollLeft += 800;
  };
  const scrollLeft4 = () => {
    scrollRef4.current.scrollLeft -= 800;
  };
  const scrollRight4 = () => {
    scrollRef4.current.scrollLeft += 800;
  };
  const scrollLeft5 = () => {
    scrollRef5.current.scrollLeft -= 800;
  };
  const scrollRight5 = () => {
    scrollRef5.current.scrollLeft += 800;
  };
  const scrollLeft6 = () => {
    scrollRef6.current.scrollLeft -= 800;
  };
  const scrollRight6 = () => {
    scrollRef6.current.scrollLeft += 800;
  };
  useEffect(() => {
    checkloginstatus();
    const handleClickOutside = (event) => {
      if (
        searchContainerRef.current &&
        !searchContainerRef.current.contains(event.target) &&
        showBookListContainerRef.current &&
        !showBookListContainerRef.current.contains(event.target)
      ) {
        setIsVisible(false);
      } else {
        setIsVisible(true); 
      }
    };
  
    document.addEventListener("click", handleClickOutside);
    
    return () => {
      document.removeEventListener("click", handleClickOutside);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);


  const handleBookClick = (element) => {
    localStorage.setItem("selectedBook", JSON.stringify(element));
    const userloggedIn=localStorage.getItem("Login Success");
   navigate(`/Addtocart?user=${encodeURIComponent(userloggedIn)}`);
  };
  const selectbook=(element)=>{
    localStorage.setItem("selectedBook", JSON.stringify(element));
    const userloggedIn=localStorage.getItem("Login Success");
   navigate(`/Addtocart?user=${encodeURIComponent(userloggedIn)}`);
  }
  const filteredBook1 = databook.filter((book) =>
    book.title.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const filteredBook2 = databook2.filter((book) =>
    book.title.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const filteredBook3 = databook3.filter((book) =>
    book.title.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const filteredBook4 = databook4.filter((book) =>
    book.title.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const filteredBook5 = databook5.filter((book) =>
    book.title.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const filteredBook6 = databook6.filter((book) =>
    book.title.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const myorders=()=>{
    const userloggedIn=localStorage.getItem("Login Success");
    navigate(`/Addtocart?user=${encodeURIComponent(userloggedIn)}`);
  }
  const mystery = () => {
    const container9 = document.querySelector('.container9');
    if (container9) {
      container9.scrollIntoView({ behavior: 'smooth' });
        window.scrollBy({
          top: 700, 
          left: 0,
          behavior: 'smooth',
        });
    }
  };
  const history = () => {
    const container9 = document.querySelector('.container9');
    if (container9) {
      container9.scrollIntoView({ behavior: 'smooth' });
        window.scrollBy({
          top: 1500, 
          left: 0,
          behavior: 'smooth',
        });
    }
  };
  const science = () => {
    const container9 = document.querySelector('.container9');
    if (container9) {
      container9.scrollIntoView({ behavior: 'smooth' });
        window.scrollBy({
          top: 2400, 
          left: 0,
          behavior: 'smooth',
        });
    }
  };
  const adventure = () => {
    const container9 = document.querySelector('.container9');
    if (container9) {
      container9.scrollIntoView({ behavior: 'smooth' });
        window.scrollBy({
          top: 3400, 
          left: 0,
          behavior: 'smooth',
        });
    }
  };
  const horror = () => {
    const container9 = document.querySelector('.container9');
    if (container9) {
      container9.scrollIntoView({ behavior: 'smooth' });
        window.scrollBy({
          top: 4300, 
          left: 0,
          behavior: 'smooth',
        });
    }
  };
  const fantasy = () => {
    const container9 = document.querySelector('.container9');
    if (container9) {
      container9.scrollIntoView({ behavior: 'smooth' });
        window.scrollBy({
          top: 5200, 
          left: 0,
          behavior: 'smooth',
        });
    }
  };
  const redirectohome=()=>{
    const userloggedIn=localStorage.getItem("Login Success");
    navigate(`/home?user=${encodeURIComponent(userloggedIn)}`);
  }
  return (
    <div>
      <section>
        <nav>
          <div className="container1">
            <div className="container2">
            {userdetails?(
              <div className="container3" onClick={redirectohome}>
                <img
                  src="https://static-assets-web.flixcart.com/batman-returns/batman-returns/p/images/fkheaderlogo_exploreplus-44005d.svg"
                  width="200"
                  height="80"
                  title="Flipkart"
                />
              </div>
            ):(
              <div className="container3">
                <img
                  src="https://static-assets-web.flixcart.com/batman-returns/batman-returns/p/images/fkheaderlogo_exploreplus-44005d.svg"
                  width="200"
                  height="80"
                  title="Flipkart"
                />
              </div>
            )}
             
              <div className="searchcontainer" ref={searchContainerRef}>
                <button
                  id="searchbtn"
                  className="_2iLD__"
                  type="submit"
                  aria-label="Search for Products, Brands and More"
                  title="Search for Products, Brands and More"
                >
                  <svg
                    width="24"
                    height="24"
                    className=""
                    viewBox="0 0 24 24"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <title>Search Icon</title>
                    <path
                      d="M10.5 18C14.6421 18 18 14.6421 18 10.5C18 6.35786 14.6421 3 10.5 3C6.35786 3 3 6.35786 3 10.5C3 14.6421 6.35786 18 10.5 18Z"
                      stroke="#717478"
                      stroke-width="1.4"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    ></path>
                    <path
                      d="M16 16L21 21"
                      stroke="#717478"
                      stroke-width="1.4"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    ></path>
                  </svg>
                </button>
                <input
                  className="searchinputbox" value={searchTerm} onChange={(e)=>setSearchTerm(e.target.value)}
                  placeholder={"Search for Products,Brands and More"}
                />
              </div>
              <div className="logincontainer">
                <div style={{ marginTop: "0.3rem" }}>
                  <div className="icon"></div>
                </div>
                <li id="container4" className="nav-item dropdown">
                  {userdetails ? (
                    <>
                      <a
                        className="nav-link dropdown-toggle"
                        role="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        {firstword}{" "}
                      </a>
                    </>
                  ) : (
                    <a
                      className="nav-link dropdown-toggle"
                      role="button"
                      data-bs-toggle="dropdown"
                      aria-expanded="false"
                    >
                      Login{" "}
                    </a>
                  )}

                  <ul
                    className="dropdown-menu"
                    style={{
                      fontSize: "1.3rem",
                      position: "relative",
                      zIndex: 1,
                    }}
                  >
                    {userdetails ? (
                      firstName
                    ) : (
                      <li>
                        <a
                          className="dropdown-item"
                          onClick={redirecttologinpage}
                        >
                          New Customer?{" "}
                          <span
                            style={{
                              color: "rgb(72, 111, 240)",
                              fontWeight: "bold",
                            }}
                          >
                            Sign Up
                          </span>
                        </a>
                      </li>
                    )}
                    <hr />
                    {userdetails ? (
                      ``
                    ) : (
                      <li onClick={redirecttologinpage}>
                        <a
                          className="dropdown-item"
                          style={{ display: "flex" }}
                        >
                          <div className="_3pKU-e">
                            <img
                              className="SFnind"
                              src="https://static-assets-web.flixcart.com/batman-returns/batman-returns/p/images/profile-52e0dc.svg"
                              alt="My Profile"
                              width="24"
                              height="24"
                            />
                          </div>{" "}
                          &nbsp;Login
                        </a>
                      </li>
                    )}
                    {userdetails ? (
                      <>
                        <li onClick={myorders}>
                          <a className="dropdown-item">
                            <img
                              className="SFnind"
                              src="https://static-assets-web.flixcart.com/batman-returns/batman-returns/p/images/orders-bfe8c4.svg"
                              alt="Orders"
                              width="24"
                              height="24"
                            ></img>
                            &nbsp; Orders
                          </a>
                        </li>
                      </>
                    ) : (
                      <>
                        <li onClick={redirecttologinpage}>
                          <a className="dropdown-item">
                            <img
                              className="SFnind"
                              src="https://static-assets-web.flixcart.com/batman-returns/batman-returns/p/images/orders-bfe8c4.svg"
                              alt="Orders"
                              width="24"
                              height="24"
                            ></img>
                            &nbsp; Orders
                          </a>
                        </li>
                      </>
                    )}

                    {userdetails ? (
                      <>
                        <li style={{ display: "flex", marginLeft: "0.5rem" }}>
                          <img
                            src="../images/logout.svg"
                            className="logout"
                          ></img>
                          <a className="dropdown-item" href="/logout">
                            Logout
                          </a>
                        </li>
                      </>
                    ) : (
                      ``
                    )}
                  </ul>
                </li>
              </div>
              {userdetails ? (
                <>
                  <div className="container5" onClick={myorders}>
                    <img
                      src="https://static-assets-web.flixcart.com/batman-returns/batman-returns/p/images/header_cart-eed150.svg"
                      alt="Cart"
                      className="_1XmrCc"
                      width="24"
                      height="24"
                    ></img>
                    &nbsp;&nbsp;Cart
                  </div>
                </>
              ) : (
                ``
              )}
            </div>
            <section>
            {userdetails?(
              <div className="showbooklistcontainer" ref={showBookListContainerRef}
    style={{ display: isVisible ? "block" : "none" }}>
        {userdetails ? (
          filteredBook1.map((element) => (
            <div style={{ marginTop: "2rem" }} key={element.id}>
              <ul>
                <li className="booktitle" onClick={()=>selectbook(element)}>{element.title}</li>
              </ul>
            </div>
          ))
        ) : (
          ""
        )}
        {userdetails ? (
          filteredBook2.map((element) => (
            <div  key={element.id}>
              <ul>
                <li  className="booktitle"onClick={()=>selectbook(element)}>{element.title}</li>
              </ul>
            </div>
          ))
        ) : (
          ""
        )}
        {userdetails ? (
          filteredBook3.map((element) => (
            <div  key={element.id}>
              <ul>
                <li  className="booktitle" onClick={()=>selectbook(element)}>{element.title}</li>
              </ul>
            </div>
          ))
        ) : (
          ""
        )}
        {userdetails ? (
          filteredBook4.map((element) => (
            <div  key={element.id}>
              <ul>
                <li  className="booktitle" onClick={()=>selectbook(element)}>{element.title}</li>
              </ul>
            </div>
          ))
        ) : (
          ""
        )}
        {userdetails ? (
          filteredBook5.map((element) => (
            <div  key={element.id}>
              <ul>
                <li  className="booktitle" onClick={()=>selectbook(element)}>{element.title}</li>
              </ul>
            </div>
          ))
        ) : (
          ""
        )}
        {userdetails ? (
          filteredBook6.map((element) => (
            <div  key={element.id}>
              <ul>
                <li  className="booktitle" onClick={()=>selectbook(element)}>{element.title}</li>
              </ul>
            </div>
          ))
        ) : (
          ""
        )}
      </div>
            ):(``)}
      
    </section>
          </div>
        </nav>
      </section>
      <section>
        <div className="container6">
          <div className="container7">
            <div className="container8">
              <div className="container9" onClick={mystery}>
                <img src="../images/Mystery.png" className="imgcontainer" />
                <div style={{ textAlign: "center" }}>
                  <h5 style={{ marginLeft: "-3rem" }}>Mystery</h5>
                </div>
              </div>
            </div>

            <div className="container8">
              <div className="container9" onClick={history}>
                <img src="../images/History.png" className="imgcontainer" />
                <div style={{ textAlign: "center" }}>
                  <h5 style={{ marginLeft: "-3rem" }}>History</h5>
                </div>
              </div>
            </div>

            <div className="container8">
              <div className="container9" onClick={science}>
                <img
                  src="../images/science fiction.png"
                  className="imgcontainer"
                />
                <div style={{ textAlign: "center", marginLeft: "-3rem" }}>
                  <h5>
                    Science <br />
                    Fiction
                  </h5>
                </div>
              </div>
            </div>

            <div className="container8">
              <div className="container9" onClick={adventure}>
                <img
                  src="../images/Adventure fiction.png"
                  className="imgcontainer"
                />
                <div style={{ textAlign: "center", marginLeft: "-3rem" }}>
                  <h5>
                    Adventure <br /> Fiction
                  </h5>
                </div>
              </div>
            </div>

            <div className="container8">
              <div className="container9" onClick={horror}>
                <img src="../images/Horror.png" className="imgcontainer" />
                <div style={{ textAlign: "center" }}>
                  <h5 style={{ marginLeft: "-3rem" }}>Horror</h5>
                </div>
              </div>
            </div>

            <div className="container8">
              <div className="container9" onClick={fantasy}>
                <img src="../images/Fantasy.png" className="imgcontainer" />
                <div style={{ textAlign: "center" }}>
                  <h5 style={{ marginLeft: "-3rem" }}>Fantasy</h5>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="container10">
          <div
            id="carouselExampleAutoplaying"
            className="carousel slide"
            data-bs-ride="carousel"
            data-bs-interval="3000"
          >
            <div className="carousel-indicators">
              <button
                type="button"
                data-bs-target="#carouselExampleCaptions"
                data-bs-slide-to="0"
                data-bs-interval="3000"
                className="active"
                aria-current="true"
                aria-label="Slide 1"
              ></button>
              <button
                type="button"
                data-bs-target="#carouselExampleCaptions"
                data-bs-slide-to="1"
                data-bs-interval="3000"
                aria-label="Slide 2"
              ></button>
              <button
                type="button"
                data-bs-target="#carouselExampleCaptions"
                data-bs-slide-to="2"
                data-bs-interval="3000"
                aria-label="Slide 3"
              ></button>
              <button
                type="button"
                data-bs-target="#carouselExampleCaptions"
                data-bs-slide-to="3"
                data-bs-interval="3000"
                aria-current="true"
                aria-label="Slide 4"
              ></button>
              <button
                type="button"
                data-bs-target="#carouselExampleCaptions"
                data-bs-slide-to="4"
                data-bs-interval="3000"
                aria-label="Slide 5"
              ></button>
              <button
                type="button"
                data-bs-target="#carouselExampleCaptions"
                data-bs-slide-to="5"
                data-bs-interval="3000"
                aria-label="Slide 6"
              ></button>
              <button
                type="button"
                data-bs-target="#carouselExampleCaptions"
                data-bs-slide-to="6"
                data-bs-interval="3000"
                aria-label="Slide 7"
              ></button>
            </div>
            <div className="carousel-inner">
              <div className="carousel-item active">
                <img
                  src="../images/book1.jpg"
                  className="d-block w-100 bookimg"
                  alt="book1"
                />
              </div>
              <div className="carousel-item">
                <img
                  src="../images/book2.jpg"
                  className="d-block w-100 bookimg"
                  alt="book2"
                />
              </div>
              <div className="carousel-item">
                <img
                  src="../images/book3.jpg"
                  className="d-block w-100 bookimg"
                  alt="book3"
                />
              </div>
              <div className="carousel-item">
                <img
                  src="../images/book4.jpg"
                  className="d-block w-100 bookimg"
                  alt="book4"
                />
              </div>
              <div className="carousel-item">
                <img
                  src="../images/book5.jpg"
                  className="d-block w-100 bookimg"
                  alt="book5"
                />
              </div>
              <div className="carousel-item">
                <img
                  src="../images/book6.jpg"
                  className="d-block w-100 bookimg"
                  alt="book6"
                />
              </div>
              <div className="carousel-item">
                <img
                  src="../images/book7.jpg"
                  className="d-block w-100 bookimg"
                  alt="book7"
                />
              </div>
            </div>
            <button
              className="carousel-control-prev"
              type="button"
              data-bs-target="#carouselExampleAutoplaying"
              data-bs-slide="prev"
            >
              <span
                className="carousel-control-prev-icon"
                aria-hidden="true"
              ></span>
              <span className="visually-hidden">Previous</span>
            </button>
            <button
              className="carousel-control-next"
              type="button"
              data-bs-target="#carouselExampleAutoplaying"
              data-bs-slide="next"
            >
              <span
                className="carousel-control-next-icon"
                aria-hidden="true"
              ></span>
              <span className="visually-hidden">Next</span>
            </button>
          </div>
        </div>
      </section>

      <section>
        <div className="container11">
          <div className="container12">
            <p>Mystery Books</p>

            {userdetails ? (
              <>
                <div className="showbooks-wrapper">
                  <button
                    className="scroll-btn"
                    onClick={scrollLeft1}
                  >{`<`}</button>

                  <div className="scroll-container" ref={scrollRef1}>
                    {databook.map((element) => (
                      <div key={element.id} className="book-card">
                        <img
                          src={`/images/${element.img}`}
                          alt={element.title}
                          className="booksimages"
                          onClick={() => handleBookClick(element)}
                        />
                        <div className="imagetitle" id="historyimgtitle">
                          <p>{element.title}</p>
                        </div>
                        <p className="Bookprice">₹{`${element.Price}`}</p>
                      </div>
                    ))}
                  </div>

                  <button
                    className="scroll-btn"
                    onClick={scrollRight1}
                  >{`>`}</button>
                </div>
              </>
            ) : (
              <>
                <div className="showalert">
                  <div className="alertdiv">
                    <h1 className="alertmsg">Please Login to view books</h1>
                    &nbsp;&nbsp;
                    <button className="loginbtn" onClick={redirecttologinpage}>
                      Login
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </section>
      <section>
        <div className="container13">
          <div className="container12">
            <p>History Books</p>

            {userdetails ? (
              <>
                <div className="showbooks-wrapper">
                  <button
                    className="scroll-btn"
                    onClick={scrollLeft2}
                  >{`<`}</button>

                  <div className="scroll-container" ref={scrollRef2}>
                    {databook2.map((element) => (
                      <div key={element.id} className="book-card2">
                        <img
                          src={`/images/${element.img}`}
                          alt={element.title}
                          className="booksimages"
                          onClick={() => handleBookClick(element)}
                        />
                        <div className="imagetitle">
                          <p>{element.title}</p>
                        </div>

                        <p className="Bookprice2">₹{`${element.Price}`}</p>
                      </div>
                    ))}
                  </div>

                  <button
                    className="scroll-btn"
                    onClick={scrollRight2}
                  >{`>`}</button>
                </div>
              </>
            ) : (
              <>
                <div className="showalert">
                  <div className="alertdiv">
                    <h1 className="alertmsg">Please Login to view books</h1>
                    &nbsp;&nbsp;
                    <button className="loginbtn" onClick={redirecttologinpage}>
                      Login
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </section>
      <section>
        <div className="container14">
          <div className="container12">
            <p>Science Fiction</p>

            {userdetails ? (
              <>
                <div className="showbooks-wrapper">
                  <button
                    className="scroll-btn"
                    onClick={scrollLeft3}
                  >{`<`}</button>

                  <div className="scroll-container" ref={scrollRef3}>
                    {databook3.map((element) => (
                      <div key={element.id} className="book-card2">
                        <img
                          src={`/images/${element.img}`}
                          alt={element.title}
                          className="booksimages"
                          onClick={() => handleBookClick(element)}
                        />
                        <div className="imagetitle">
                          <p>{element.title}</p>
                        </div>

                        <p className="Bookprice2">₹{`${element.Price}`}</p>
                      </div>
                    ))}
                  </div>

                  <button
                    className="scroll-btn"
                    onClick={scrollRight3}
                  >{`>`}</button>
                </div>
              </>
            ) : (
              <>
                <div className="showalert">
                  <div className="alertdiv">
                    <h1 className="alertmsg">Please Login to view books</h1>
                    &nbsp;&nbsp;
                    <button className="loginbtn" onClick={redirecttologinpage}>
                      Login
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </section>

        <div className="container15">
          <div className="container12">
            <p>Adventure Fiction</p>

            {userdetails ? (
              <>
                <div className="showbooks-wrapper">
                  <button
                    className="scroll-btn"
                    onClick={scrollLeft4}
                  >{`<`}</button>

                  <div className="scroll-container" ref={scrollRef4}>
                    {databook4.map((element) => (
                      <div key={element.id} className="book-card3">
                        <img
                          src={`/images/${element.img}`}
                          alt={element.title}
                          className="booksimages"
                          onClick={() => handleBookClick(element)}
                        />
                        <div className="imagetitle">
                          <p>{element.title}</p>
                        </div>

                        <p className="Bookprice3">₹{`${element.Price}`}</p>
                      </div>
                    ))}
                  </div>

                  <button
                    className="scroll-btn"
                    onClick={scrollRight4}
                  >{`>`}</button>
                </div>
              </>
            ) : (
              <>
                <div className="showalert">
                  <div className="alertdiv">
                    <h1 className="alertmsg">Please Login to view books</h1>
                    &nbsp;&nbsp;
                    <button className="loginbtn" onClick={redirecttologinpage}>
                      Login
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
     

      <section>
        <div className="container16">
          <div className="container12">
            <p>Horror Books</p>

            {userdetails ? (
              <>
                <div className="showbooks-wrapper">
                  <button
                    className="scroll-btn"
                    onClick={scrollLeft5}
                  >{`<`}</button>

                  <div className="scroll-container" ref={scrollRef5}>
                    {databook5.map((element) => (
                      <div key={element.id} className="book-card4">
                        <img
                          src={`/images/${element.img}`}
                          alt={element.title}
                          className="booksimages"
                          onClick={() => handleBookClick(element)}
                        />
                        <div className="imagetitle">
                          <p>{element.title}</p>
                        </div>

                        <p className="Bookprice4">₹{`${element.Price}`}</p>
                      </div>
                    ))}
                  </div>

                  <button
                    className="scroll-btn"
                    onClick={scrollRight5}
                  >{`>`}</button>
                </div>
              </>
            ) : (
              <>
                <div className="showalert">
                  <div className="alertdiv">
                    <h1 className="alertmsg">Please Login to view books</h1>
                    &nbsp;&nbsp;
                    <button className="loginbtn" onClick={redirecttologinpage}>
                      Login
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </section>

      <section>
        <div className="container17">
          <div className="container12">
            <p>Fantasy Books</p>

            {userdetails ? (
              <>
                <div className="showbooks-wrapper">
                  <button
                    className="scroll-btn"
                    onClick={scrollLeft6}
                  >{`<`}</button>

                  <div className="scroll-container" ref={scrollRef6}>
                    {databook6.map((element) => (
                      <div key={element.id} className="book-card4">
                        <img
                          src={`/images/${element.img}`}
                          alt={element.title}
                          className="booksimages"
                          onClick={() => handleBookClick(element)}
                        />
                        <div className="imagetitle">
                          <p>{element.title}</p>
                        </div>

                        <p className="Bookprice4">₹{`${element.Price}`}</p>
                      </div>
                    ))}
                  </div>

                  <button
                    className="scroll-btn"
                    onClick={scrollRight6}
                  >{`>`}</button>
                </div>
              </>
            ) : (
              <>
                <div className="showalert">
                  <div className="alertdiv">
                    <h1 className="alertmsg">Please Login to view books</h1>
                    &nbsp;&nbsp;
                    <button className="loginbtn" onClick={redirecttologinpage}>
                      Login
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
