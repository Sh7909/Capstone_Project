/* eslint-disable no-useless-escape */
import React, {  useState } from 'react';
import { useNavigate } from "react-router-dom"; 

import '../index.css'
const First = () => {
  const signup=()=>{
    const login=document.querySelector('.login');
    const signup=document.querySelector('.signup');
    const loginsignupbox=document.querySelector('.loginsignupbox');
    login.style.display="none";
    loginsignupbox.style.height="45rem";
    loginsignupbox.style.top="8%";
    loginsignupbox.style.marginLeft="27rem";
    signup.style.display="block";
  }
  const login=()=>{
    const login=document.querySelector('.login');
    const signup=document.querySelector('.signup');
    const loginsignupbox=document.querySelector('.loginsignupbox');
    login.style.display="block";
    loginsignupbox.style.height="28rem";
    loginsignupbox.style.top="20%";
    loginsignupbox.style.marginLeft="36rem";
    signup.style.display="none";
  }
  const[email,setEmail]=useState("");
  const[password1,setPassword1]=useState("");
  const[password2,setPassword2]=useState("");
  const[firstname,setFirstname]=useState("");
  const[lastname,setLastname]=useState("");

  const validatelogindetails=(e)=>{
    e.preventDefault();
    const firstnameerr=document.querySelector('#firstnameerr');
    const lastnameerr=document.querySelector('#lastnameerr');
    const emailerr=document.querySelector('#emailerr');
    const passworderr1=document.querySelector('#passworderr1');
    const passworderr2=document.querySelector('#passworderr2');

    const regex1=new RegExp('^[A-Za-z]');
    const regex2= new RegExp(
      `^[A-Za-z0-9_!#$%&'*+\/=?'{|}~^.-]+@[A-Za-z0-9.-]+$`
    );
    const regex3=new RegExp(
      `^(?=.*?[A-Za-z])(?=.*?[0-9]).{6,}$`
    );

    if(regex1.test(firstname)){
      firstnameerr.style.display="none";
    }
    else{
      firstnameerr.style.display="block";
    }
    if(regex1.test(lastname)){
      lastnameerr.style.display="none";
    }
    else{
      lastnameerr.style.display="block";
    }

    if(regex2.test(email)){
      emailerr.style.display="none";
    }
    else{
      emailerr.style.display="block";
    }

const isPassword1Valid = regex3.test(password1);
const isPassword2Valid = regex3.test(password2);
const isMatch = password1.trim() === password2.trim();

if (!isPassword1Valid) {
  passworderr1.innerHTML = "Password must be at least 6 characters, including letters and numbers!";
  passworderr1.style.display = "block";
} else {
  passworderr1.style.display = "none";
}

if (!isPassword2Valid) {
  passworderr2.innerHTML = "Password must be at least 6 characters, including letters and numbers!";
  passworderr2.style.display = "block";
} else {
  passworderr2.style.display = "none";
}

if (isPassword1Valid && isPassword2Valid && !isMatch) {
  passworderr1.innerHTML = "Passwords do not match!";
  passworderr1.style.display = "block";
  passworderr2.innerHTML = "Passwords do not match!";
  passworderr2.style.display = "block";
}

if (isPassword1Valid && isPassword2Valid && isMatch) {
 alert("Details Submitted Successfully.Please Login")
 login();
    const formdata={
      firstname:firstname,
      lastname:lastname,
      email:email,
      password1:password1,
      password2:password2,
    }
    if(formdata){

    fetch('http://localhost:3000/sendlogindata',{
      method:"POST",
      headers:{'Content-Type':"application/json"},
      body:JSON.stringify({
        Formdata:formdata,
      })
    })
    .then((res) => {
      if (!res.ok) {
        const text = res.text(); 
        throw new Error(text || "Server error");
      }
      return res.json();
    })
    .then((data)=>console.log(data))
  }
  else{
    alert("Please Fill all details carefully!")
  }
}
}
const[loginemailinput,setLoginemailinput]=useState("");
const[loginpassinput,setLoginpassinput]=useState("");
const navigate = useNavigate();
const handleloginsubmit=(e)=>{
  e.preventDefault();
  const emailerr=document.querySelector('.emailerr');
   const passworderr=document.querySelector('.passworderr');
  const regex1= new RegExp(
    `^[A-Za-z0-9_!#$%&'*+\/=?'{|}~^.-]+@[A-Za-z0-9.-]+$`
  );
  const regex2=new RegExp(
    `^(?=.*?[A-Za-z])(?=.*?[0-9]).{6,}$`
  );
  if(!regex1.test(loginemailinput)){
    emailerr.style.display="block";
  }
  else{
    emailerr.style.display="none";
  }
  if(!regex2.test(loginpassinput)){
    passworderr.style.display="block";
  }
  else{
    passworderr.style.display="none";
  }
 fetch('http://localhost:3000/checkvalidation',{
  method:"POST",
  headers:{'Content-Type':"application/json"},
  body:JSON.stringify({
    loginemailinput:loginemailinput,
    loginpassinput:loginpassinput,
  })
 })
 .then((res)=>{
  return res.json();
 })
 .then((data)=>{
  if(data.found){
 const emailpart=data.email;
 const emailFirstPart = emailpart?.split('@')[0];
    navigate(`/home?user=${encodeURIComponent(emailFirstPart)}`); 
    localStorage.setItem("Login Success",(emailFirstPart));
    alert(data.message);
  }
  else{
    alert(data.message);
  }
 });
  }
  return (
    <>
      <div>
        <img src="../images/image1.webp" className='imagestyling'/>
      </div>
      <div className='loginsignupcontainer'>
        <div className="loginsignupbox">
        <div className='login'>
          <div className='Logintxt'>
            <p>Login</p>
          </div>
          <form onSubmit={handleloginsubmit}>
          <p className='emailaddress'>Email Address: <span style={{color:"red"}}>*</span></p>
          <input type="text" placeholder='abc@gmail.com' className='emailinput'
            value={loginemailinput} onChange={(e)=>setLoginemailinput(e.target.value)}
          />
          <br />
          <div className='emailerr'>Please Enter Valid Email!</div>
          <br />
          <p className='password'>Password:<span style={{color:"red"}}>*</span> </p>
          <input type="password" placeholder='Enter 6 characters or more' 
          className='passwordinput' 
          value={loginpassinput} onChange={(e)=>setLoginpassinput(e.target.value)}/>
          <br />
          <div className='passworderr'>Please Enter Valid Password!</div>
          <div style={{display:"flex"}}>
          <input type="checkbox" className='remember' /> 
          <p style={{marginTop:"2rem",marginLeft:"0.5rem",color:"white"}} >Remember me</p>
          </div>
          <button className='Loginbtn'>
            <p style={{marginTop:"0.3rem"}}>Login</p>
          </button>

          <div style={{display:"flex"}}>
            <p style={{marginLeft:"0.5rem",color:"white"}}>Doesn't have an account yet?</p>
            <span style={{marginLeft:"0.5rem"}}>
              <a className='SignUp' onClick={signup}>Sign Up</a>
            </span>
          </div>
</form>
        </div>
        <div className='signup'>
        <div className='signuptxt'>
            <p>SignUp Form</p>
          </div>
          <form onSubmit={validatelogindetails} method='post'>
          <p className='first_name'>First Name:<span style={{color:"red"}}>*</span></p>
          <input type="text" placeholder='Enter your name' 
          className='firstnameinput' value={firstname}
           onChange={(e)=>setFirstname(e.target.value)}/>
          <br />
          <div id='firstnameerr'>Please Enter Valid First Name!</div>
          <br />
          <p className='last_name'>Last Name:<span style={{color:"red"}}>*</span></p>
          <input type="text" placeholder='Enter your name'
           className='lastnameinput' value={lastname} onChange={(e)=>setLastname(e.target.value)}/>
          <br />
          <div id='lastnameerr'>Please Enter Valid Last Name!</div>
          <br />
          <p className='emailaddress'>Email Address:<span style={{color:"red"}}>*</span></p>
          <input type="text" placeholder='abc@gmail.com' className='emailinput'
            value={email} onChange={(e)=>setEmail(e.target.value)}
          />
          <br />
          <div id='emailerr'>Please Enter Valid Email!</div>
          <br />
          <p className='password'>Password:<span style={{color:"red"}}>*</span></p>
          <input type="password" placeholder='Enter 6 characters or more' 
          className='passwordinput1' value={password1} 
          onChange={(e)=>setPassword1(e.target.value)}/>
          <br />
          <div id='passworderr1'></div>
          <br />
          <p className='password'>Confirm Password:<span style={{color:"red"}}>*</span></p>
          <input type="password" placeholder='Enter 6 characters or more' 
          className='passwordinput2' value={password2} 
          onChange={(e)=>setPassword2(e.target.value)}/>
          <br />
          <div id='passworderr2'></div>
          <br />
          <button className='Signupbtn'>
            <p style={{marginTop:"0.3rem"}}>SignUp</p>
          </button>
          </form>
          <div style={{display:"flex"}}>
            <p style={{marginLeft:"0.5rem",color:"white"}}>Already have an account?</p>
            <span style={{marginLeft:"0.5rem"}}>
              <a className='Login'  onClick={login} >Login</a>
            </span>
          </div>
        </div>
        </div>
      </div>
    </>
  )
}

export default First
