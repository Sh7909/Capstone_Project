import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router";
import "../index.css";
export default function Orders() {
  const [orderdata, setOrderdata] = useState([]);
  const [date, setDate] = useState("");
  const location = useLocation();
  const navigate = useNavigate();
  const params = new URLSearchParams(location.search);
  const userdetails = params.get("user");
  const firstName = userdetails ? userdetails.split("@")[0] : "";
  firstName.split("")[0];
  useEffect(() => {
    document.title = "Your Orders";
    const params = new URLSearchParams(location.search);
    const useremail = userdetails ? userdetails.split("@")[0] : "";
    const userdateEncoded = params.get("userdate");
  
    setDate(userdateEncoded);
  
    const existingOrdersJSON = localStorage.getItem(`orderdetails_${useremail}`);
    const existingOrders = existingOrdersJSON ? JSON.parse(existingOrdersJSON) : [];
  
    setOrderdata(existingOrders);
  }, [location, userdetails]);
  
  
  const homepage = () => {
    document.title="Home Page";
    const userloggedIn = localStorage.getItem("Login Success");
    navigate(`/home?user=${encodeURIComponent(userloggedIn)}`);
  };
  return (
    <>
     
      <section>
        <div className="backtohome" onClick={homepage}>
          <button className="btn btn-warning">Go to Home</button>
        </div>
        <br />
        <br />
        <div className="orderdata">
          <p className="text1">Your Orders</p>
          <div className="scrolldiv">
            <div className="headingdiv">
              <div>Sr.No</div>
              <div>Order_Id</div>
              <div>Item</div>
              <div>Date</div>
              <div>Amount</div>
            </div>
            <hr style={{ position: "relative", width: "100%", top: "-1rem" }} />
            {orderdata.length === 0 ? (
  <p style={{ textAlign: "center" }}>No orders yet! Start shopping 🛒</p>
) : (
  orderdata.map((element, index) => {
    return (
      <div className="showdata" key={element.id}>
  <div>{index + 1}</div>
  <div style={{ marginLeft: "-1rem" }}>{element._id?.slice(0, 8) ?? "N/A"}</div>
  <div style={{ marginLeft: "-5rem" }}>
    {element.title} x {element.quantity}
  </div>
  <div style={{ marginLeft: "-2rem" }}>{date}</div>
  <div>₹{element.Price * element.quantity}</div>
</div>

              );
  })
)}
          </div>
        </div>
      </section>
    </>
  );
}
