import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";

export default function Confirmation() {
  const location = useLocation();
  const navigate = useNavigate();
  const [cartdetails, setCartdetails] = useState([]);
  const [userdate, setUserdate] = useState("");

  useEffect(() => {
    document.title = "Thank You!";

    // Get query string params
    const params = new URLSearchParams(location.search);
    const storedCartEncoded = params.get("storedCart");
    const storedDate = params.get("formatted");
    const parsedData = JSON.parse(storedCartEncoded);
    setCartdetails(parsedData);
    setUserdate(storedDate);
  }, [location]);

  const orders = () => {
    const userloggedIn = localStorage.getItem("Login Success");
    const useremail = userloggedIn ? userloggedIn.split("@")[0] : "";

    // Get existing orders for the user
    const existingOrdersJSON = localStorage.getItem(`orderdetails_${useremail}`);
    const existingOrders = existingOrdersJSON ? JSON.parse(existingOrdersJSON) : [];

    // Remove duplicate books from the current cart
    const filteredCart = cartdetails.filter((cartItem) => {
      return !existingOrders.some((orderItem) => orderItem._id === cartItem._id);
    });

    // Combine existing orders and new filtered cart items
    const updatedOrders = [...existingOrders, ...filteredCart];

    // Save updated orders to localStorage
    localStorage.setItem(`orderdetails_${useremail}`, JSON.stringify(updatedOrders));

    // Navigate to the Orders page without passing cartdetails again
    navigate(`/Orderhistory?user=${encodeURIComponent(userloggedIn)}&userdate=${encodeURIComponent(userdate)}`);
  };

  return (
    <>
      <div className="thankstxt">
        <div>Your Order has been placed successfully.</div>
      </div>
      <br />
      <br />
      <div className="btn btn-warning gonow" onClick={orders}>
        Go to Orders
      </div>
    </>
  );
}
